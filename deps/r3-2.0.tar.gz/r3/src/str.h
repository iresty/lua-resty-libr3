#ifndef R3_STR_INTERN_H
#define R3_STR_INTERN_H

#ifdef __cplusplus
extern "C" {
#endif

void print_indent(int level);

#ifdef __cplusplus
}
#endif

#endif
